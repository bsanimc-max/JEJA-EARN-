# JEJA EARN — Telegram Mini App starter

This is a production-oriented starter for a Telegram Mini App with:
- Telegram user authentication via validated `initData`
- XP balance
- Daily check-in
- Referral tracking
- Leaderboard
- AdsGram rewarded-ad hook
- SQLite database
- Telegram webhook endpoint

## 1. Install

```bash
npm install
cp .env.example .env
npm start
```

## 2. Required secrets

Set in `.env`:

- `BOT_TOKEN`: token from @BotFather
- `WEBAPP_URL`: your public HTTPS Mini App URL
- `ADSGRAM_BLOCK_ID`: Rewarded block ID from AdsGram

Never publish `.env` or your bot token.

## 3. Telegram setup

Create the bot with @BotFather using `/newbot`.
Then configure the bot's Main Mini App to point at `WEBAPP_URL`.

The bot username cannot be changed after creation, so choose it carefully.

## 4. AdsGram

Create a publisher account, create a Rewarded block, pass moderation, then put its block ID in `ADSGRAM_BLOCK_ID`.

The frontend already loads the AdsGram SDK and calls:

```js
const controller = window.Adsgram.init({ blockId: config.adsgramBlockId });
await controller.show();
```

Only credit XP after the rewarded promise completes. Add stronger server-side anti-abuse controls before public launch.

## 5. Production checklist

- Deploy behind HTTPS.
- Configure Telegram webhook:
  `POST https://api.telegram.org/bot<BOT_TOKEN>/setWebhook`
  with your `/api/bot/webhook` URL.
- Replace SQLite with PostgreSQL for a larger user base.
- Add rate limits, audit logs, admin authentication and withdrawal review.
- Do not promise a cash value for XP unless you have a funded, sustainable payout model.
- Add a privacy policy, terms, anti-fraud rules and clear withdrawal conditions.
