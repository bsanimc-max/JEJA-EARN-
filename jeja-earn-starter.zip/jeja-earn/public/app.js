const tg = window.Telegram?.WebApp;
tg?.ready();
tg?.expand();

let config = { xpPerAd: 100, xpPerReferral: 2500, dailyXp: 10, adsgramBlockId: "" };
let me = null;

function initData() {
  return tg?.initData || "";
}

async function api(path, options = {}) {
  const headers = {
    "content-type": "application/json",
    "x-telegram-init-data": initData(),
    ...(options.headers || {})
  };
  const res = await fetch(path, {...options, headers});
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}

function getStartParam() {
  return tg?.initDataUnsafe?.start_param || "";
}

async function boot() {
  config = await fetch("/api/config").then(r => r.json());
  document.getElementById("adReward").textContent = config.xpPerAd;

  try {
    const r = await api("/api/register", {
      method: "POST",
      body: JSON.stringify({ referral: getStartParam() || null })
    });
    me = r.user;
    render();
    loadLeaderboard();
  } catch (e) {
    alert("Open JEJA EARN from Telegram so your account can be verified.");
  }
}

function render() {
  document.getElementById("xp").textContent = Number(me.xp || 0).toLocaleString();
  document.getElementById("usd").textContent = (Number(me.xp || 0) * 0.000005).toFixed(4);
  document.getElementById("streak").textContent = me.streak || 0;
  document.getElementById("refs").textContent = me.referrals || 0;
  document.getElementById("ads").textContent = "—";

  const botUsername = "YOUR_BOT_USERNAME";
  const link = `https://t.me/${botUsername}?startapp=${me.telegram_id}`;
  document.getElementById("refLink").textContent = link;
}

async function checkin() {
  try {
    const r = await api("/api/checkin", {method:"POST", body:"{}"});
    me.xp += r.xp; me.streak = r.streak; render();
    alert(`🔥 +${r.xp} XP. Streak: ${r.streak}`);
  } catch(e) { alert(e.message); }
}

async function watchAd() {
  if (!config.adsgramBlockId) {
    alert("AdsGram blockId is not configured yet.");
    return;
  }

  try {
    const controller = window.Adsgram.init({ blockId: config.adsgramBlockId });
    await controller.show();

    const r = await api("/api/ad-complete", {
      method: "POST",
      body: JSON.stringify({type:"rewarded"})
    });
    me.xp += r.xp;
    render();
    alert(`🎉 +${r.xp} XP`);
  } catch(e) {
    console.log(e);
    alert("Ad was not completed or no ad is available right now.");
  }
}

async function loadLeaderboard() {
  const data = await fetch("/api/leaderboard").then(r => r.json());
  const box = document.getElementById("leaderboard");
  box.innerHTML = data.rows.map((r,i) =>
    `<div class="row"><span>#${i+1}</span>&nbsp;&nbsp;<b>${escapeHtml(r.first_name || r.username || "User")}</b><span>${r.referrals} refs</span></div>`
  ).join("");
}

function copyReferral() {
  const text = document.getElementById("refLink").textContent;
  navigator.clipboard?.writeText(text);
  alert("Referral link copied.");
}

function withdrawInfo() {
  alert("Withdrawal module comes next: minimum XP, wallet address, request queue and admin approval.");
}

function scrollToId(id) {
  document.getElementById(id)?.scrollIntoView({behavior:"smooth"});
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}

boot();
